define(['Modernizr'], function( Modernizr ) {
  // postMessage
  // http://www.w3.org/TR/html5/comms.html#posting-messages
  Modernizr.addTest('postmessage', !!window.postMessage);
});
