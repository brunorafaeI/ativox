define(['Modernizr'], function( Modernizr ) {
  Modernizr.addTest('applicationcache', !!window.applicationCache);
});
