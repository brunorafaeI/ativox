define(function() {
  var toStringFn = ({}).toString;
  return toStringFn;
});
