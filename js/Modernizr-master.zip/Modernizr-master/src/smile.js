define(function() {
  var smile = ':)';
  return smile;
});
