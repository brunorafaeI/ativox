define(function() {
  var attrs = {};
  return attrs;
});
