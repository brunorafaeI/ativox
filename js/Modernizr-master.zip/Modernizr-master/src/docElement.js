define(function() {
  var docElement = document.documentElement;
  return docElement;
});
