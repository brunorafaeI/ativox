define(['classes'], function( classes ) {
  var slice = classes.slice;
  return slice;
});
