define(['createElement'], function(createElement) {
  var inputElem = createElement('input');
  return inputElem;
});
