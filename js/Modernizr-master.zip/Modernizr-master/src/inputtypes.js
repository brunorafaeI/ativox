define(function() {
  var inputtypes = 'search tel url email datetime date month week time datetime-local number range color'.split(' ');
  return inputtypes;
});
