define(['ModernizrProto', 'injectElementWithStyles'], function( ModernizrProto, injectElementWithStyles ) {
  var testStyles = ModernizrProto.testStyles = injectElementWithStyles;
  return testStyles;
});
