define(['ModernizrProto', 'testPropsAll'], function( ModernizrProto, testPropsAll ) {
  var testAllProps = ModernizrProto.testAllProps = testPropsAll;
  return testAllProps;
});
