define(function() {
  var inputattrs = 'autocomplete autofocus list placeholder max min multiple pattern required step'.split(' ');
  return inputattrs;
});
