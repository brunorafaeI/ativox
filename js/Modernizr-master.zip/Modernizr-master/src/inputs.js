define(function() {
  var inputs = {};
  return inputs;
});
